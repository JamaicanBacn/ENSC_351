Joystick: \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/Scrt1.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/crti.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/crtbeginS.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libasan_preinit.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libasan.so \
  CMakeFiles/Joystick.dir/src/joystick.c.o \
  CMakeFiles/Joystick.dir/src/main.c.o \
  ../hal/libhal.a \
  /lib/aarch64-linux-gnu/libgpiod.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so \
  /usr/aarch64-linux-gnu/lib/libm.so.6 \
  /usr/aarch64-linux-gnu/lib/libmvec.so.1 \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1 \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libpthread.a \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so \
  /usr/aarch64-linux-gnu/lib/libc.so.6 \
  /usr/aarch64-linux-gnu/lib/libc_nonshared.a \
  /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1 \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/crtendS.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/crtn.o \
  /usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1 \
  /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/Scrt1.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/crti.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/crtbeginS.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libasan_preinit.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libasan.so:

CMakeFiles/Joystick.dir/src/joystick.c.o:

CMakeFiles/Joystick.dir/src/main.c.o:

../hal/libhal.a:

/lib/aarch64-linux-gnu/libgpiod.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libm.so:

/usr/aarch64-linux-gnu/lib/libm.so.6:

/usr/aarch64-linux-gnu/lib/libmvec.so.1:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libpthread.a:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libc.so:

/usr/aarch64-linux-gnu/lib/libc.so.6:

/usr/aarch64-linux-gnu/lib/libc_nonshared.a:

/usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/libgcc.a:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/crtendS.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/crtn.o:

/usr/lib/gcc-cross/aarch64-linux-gnu/14/../../../../aarch64-linux-gnu/lib/../lib/libgcc_s.so.1:

/usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1:
